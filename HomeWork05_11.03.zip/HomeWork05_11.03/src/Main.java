public class Main {
    public static void main(String[] args) {
        byte b = 127;
        System.out.println(b);
        b++;
        System.out.println(b);
    }
}