public class Main {
    static final char MALE = 'M';
    static final char FEMALE = 'F';
    public static void main(String[] args) {
        int vasyaAge = 34;
        byte vasyaFingers = 20;
        short vasyaHeight = 155;
        long vasyaPhone = 999888333;
        float vasyaBank1 = 300.555f;
        double vasyaBank2 = 450.99999;
        char vasyaSex = MALE;
        boolean vasyaVaccine = true;
        System.out.println("Возраст " + vasyaAge);
        System.out.println("Рост " + vasyaHeight);
        System.out.println("Количество пальцев " + vasyaFingers);
        System.out.println("Номер телефона " + vasyaPhone);
        System.out.println("Счёт в банке1 " + vasyaBank1);
        System.out.println("Счёт в банке2 " + vasyaBank2);
        System.out.println("Пол " + vasyaSex);
        System.out.println("Прививки " + vasyaVaccine);
        vasyaAge = vasyaAge + 1;
        vasyaFingers = 19;
        vasyaHeight = 158;
        System.out.println("Вася повзрослел " + vasyaAge);
        System.out.println("У Васи что-то случилось " + vasyaFingers);
        System.out.println("Вася подрос " + vasyaHeight);


    }
}