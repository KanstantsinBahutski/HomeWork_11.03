public class Main {
    public static void main(String[] args) {
        int x1 = 5 % 4;
        int x2 = 15 % 3;
        System.out.println("Остаток " + x1);
        System.out.println("Остаток " + x2);
        boolean y1 = 2 % 2 == 0;
        boolean y2 = 7 % 2 == 0;
        boolean y3 = 13 % 2 == 0;
        boolean y4 = 14 % 2 == 0;
        System.out.println("true - чётное, false - нечётное " + y1);
        System.out.println("true - чётное, false - нечётное " + y2);
        System.out.println("true - чётное, false - нечётное " + y3);
        System.out.println("true - чётное, false - нечётное " + y4);
        int z1 = 11;
        int z2 = 16;
        int z3 = 21;
        int z4 = 33;
        int z5 = 68;
        int z01 = z1 % 10;
        int z02 = z2 % 10;
        int z03 = z3 % 10;
        int z04 = z4 % 10;
        int z05 = z5 % 10;
        System.out.println("Последняя цифра " + z01);
        System.out.println("Последняя цифра " + z02);
        System.out.println("Последняя цифра " + z03);
        System.out.println("Последняя цифра " + z04);
        System.out.println("Последняя цифра " + z05);


    }
}