public class Main {
    public static void main(String[] args) {
        int i1 = 3333;
        int i2 = 4444;
        long l1 = 55555;
        long l2 = 66666;
        double d1 = 333.333;
        double d2 = 444.444;
        float f1 = 555.555f;
        float f2 = 666.666f;
        int resultII = i1 + i2;
        long resultLL =  l1 + l2;
        long resultIL = i1 + l1;
        float resultIF = i1 + f1;
        double resultID = i1 + d1;
        double resultLD =  l1 + d1;
        System.out.println(resultII);
        System.out.println(resultLL);
        System.out.println(resultIL);
        System.out.println(resultIF);
        System.out.println(resultID);
        System.out.println(resultLD);
        System.out.println("По заданию выводить было не обязательно");
    }
}