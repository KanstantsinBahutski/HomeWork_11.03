public class Main {
    public static void main(String[] args) {
        int appleQuantity = 30;
        int grapeQuantity = 25;
        int juiceContent1 = appleQuantity + grapeQuantity;
        System.out.println("Сложение " + juiceContent1);
        int juiceContent2 = appleQuantity - grapeQuantity;
        System.out.println("Вычитание " + juiceContent2);
        int juiceContent3 = appleQuantity * grapeQuantity;
        System.out.println("Умножение " + juiceContent3);
        int juiceContent4 = appleQuantity / grapeQuantity;
        System.out.println("Деление " + juiceContent4);
        int juiceContent5 = appleQuantity % grapeQuantity;
        System.out.println("Остаток " + juiceContent5);

    }
}